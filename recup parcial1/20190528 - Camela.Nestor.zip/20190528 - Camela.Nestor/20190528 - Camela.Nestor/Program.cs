﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _20190528___Camela.Nestor
{
    class Program
    {
        static void Main(string[] args)
        {
        }
    }
}
