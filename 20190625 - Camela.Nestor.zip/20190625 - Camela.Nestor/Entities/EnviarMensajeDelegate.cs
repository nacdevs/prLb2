﻿using System;

namespace Entities
{
    public delegate void EnviarMensajeDelegate(Emisor mensaje);
}
