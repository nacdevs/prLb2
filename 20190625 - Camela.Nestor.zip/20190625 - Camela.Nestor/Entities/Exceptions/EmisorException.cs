﻿using System;

namespace Entities.Exceptions
{
   
}
